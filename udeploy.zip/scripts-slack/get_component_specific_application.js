var request = require("request");
var function_call = function (app_name, udeploy_url, username, password, callback_get_component_specific_application) {
var udeploy_url = udeploy_url;
var username = username;
var password = password;
var app_name = app_name;
var url = udeploy_url + '/cli/application/componentsInApplication?application=' + app_name;
var options = { method: 'GET',
  url: url,
  auth: {
    user: username,
    password: password
  },
  qs: { active: 'true' }
 };
var active_components = '';
request(options, function (error, response, body) {

  if(error || response.statusCode != 200)
  {
          console.log("Error in getting environment: "+error);
		  callback_get_component_specific_application(error,"Error","Error");
  }
  else
  {

          body = JSON.parse(body);
          var length = body.length;

          for(i=0;i<length;i++)
          {

                  active_components = active_components + '\nID : ' + body[i].id + '\tName : ' + body[i].name + '\tDescription' +body[i].description + '\tEpochTime : ' + body[i].created + '\tComponentType : ' + body[i].componentType + '\tUserName : ' + body[i].user + '\tSecurityID : ' + body[i].securityResourceId;
          }
		  callback_get_component_specific_application("null",active_components,"null");
  }


});



}




module.exports = {
  get_component_specific_application: function_call	// MAIN FUNCTION
  
}
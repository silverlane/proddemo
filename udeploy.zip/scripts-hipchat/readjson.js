var fs = require('fs')

var obj = '';
function readworkflow(callback) {
	console.log("In reading json");
 //var cmd=method;
 //console.log(obj);
if(!obj){
obj = JSON.parse(fs.readFileSync('./workflow.json', 'utf8'));}
 //console.log(obj)
 callback(null, obj,null);

}
module.exports = {
  readworkflow_coffee: readworkflow	// MAIN FUNCTION
  
}